package com.App.BankApplication.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Account {
	
	@Id
	private int accountId;
	
	public Account() {
		
	}
	
	public Account(int accountID, int openBal, long accNumber, LocalDate date) {
		super();
		this.accountId = accountID;
		this.openBal = openBal;
		this.accNumber = accNumber;
		this.date = date;
	}

	private int openBal;
	
	@Column(name="accNumber" , updatable=false, nullable=false)
	private long accNumber;
	
	private LocalDate date;

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int acctID) {
		this.accountId = acctID;
	}

	public int getOpenBal() {
		return openBal;
	}

	public void setOpenBal(int balance) {
		this.openBal = balance;
	}

	public long getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(long accNumber) {
		this.accNumber = accNumber;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	
}