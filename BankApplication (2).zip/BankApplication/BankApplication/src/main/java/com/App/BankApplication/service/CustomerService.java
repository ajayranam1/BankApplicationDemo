package com.App.BankApplication.service;

import com.App.BankApplication.entity.Customer;

public interface CustomerService {

	public Customer saveCustomer(Customer customer);
}
