package com.App.BankApplication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.App.BankApplication.entity.Statement;

@Repository
public interface StatementRepository extends CrudRepository<Statement, Integer>,JpaRepository<Statement, Integer> {

	public List<Statement> getAllByAccountNumber(long accountNumber);
}
