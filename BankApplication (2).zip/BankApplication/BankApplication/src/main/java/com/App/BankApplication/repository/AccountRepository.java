package com.App.BankApplication.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.App.BankApplication.entity.Account;


@Repository
public interface AccountRepository extends JpaRepository<Account, Integer>{

	
	Account getOpenBalByAccNumber(long accNumber);
	
	long getAccNumberByAccountId(int accId);
	
	@Transactional
	@Modifying(clearAutomatically = true)
	@Query(value="update Account set open_bal = open_bal+? where acc_Number=?" , nativeQuery=true)
	void saveBalanceByAccNumber(int balance, long accNumber);

	@Transactional
	@Modifying(clearAutomatically = true)
	@Query(value="update Account set open_bal = open_bal-? where acc_Number=?" , nativeQuery=true)
	void withdrawAmountByAccNumber(int balance,long accNumber);
}
