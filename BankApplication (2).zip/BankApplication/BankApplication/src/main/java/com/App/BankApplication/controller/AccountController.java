package com.App.BankApplication.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.App.BankApplication.entity.Account;
import com.App.BankApplication.entity.Statement;
import com.App.BankApplication.service.AccountService;

@RestController
public class AccountController {

	@Autowired
	AccountService accServ;
	
	public long createAccount(int acctID, int balance) {
		long accNumber=new Random().nextInt(9999999);
		LocalDate date=LocalDate.now();
		Account acc=new Account(acctID,balance,accNumber,date);
		return accServ.saveAccount(acc).getAccNumber();
	}
	
	public Long getAccountDetails(int acctId) {
		return accServ.getAccountDetails(acctId);
	}
	
	@PostMapping("/transfer")
	public String transferMoney(@RequestParam long fromAccount,@RequestParam long toAccount, @RequestParam int amount,
								@RequestParam String Comment) {
		return accServ.transferAmount(fromAccount, toAccount, amount, Comment);
	}
	
	@GetMapping("/statement")
	public List<Statement> viewStatement(@RequestParam long accountNumber) {
		return accServ.viewStatement(accountNumber);
	}
}
