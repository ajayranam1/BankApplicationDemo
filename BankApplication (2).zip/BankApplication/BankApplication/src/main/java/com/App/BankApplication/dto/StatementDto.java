package com.App.BankApplication.dto;

public class StatementDto {
	
	public StatementDto(int accountNumber, String comments, int amountDebit, int amountCredit) {
		super();
		this.accountNumber = accountNumber;
		this.comments = comments;
		this.amountDebit = amountDebit;
		this.amountCredit = amountCredit;
	}
	private int accountNumber;
	private String comments;
	private int amountDebit;
	private int amountCredit;
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public int getAmountDebit() {
		return amountDebit;
	}
	public void setAmountDebit(int amountDebit) {
		this.amountDebit = amountDebit;
	}
	public int getAmountCredit() {
		return amountCredit;
	}
	public void setAmountCredit(int amountCredit) {
		this.amountCredit = amountCredit;
	}
	
}
