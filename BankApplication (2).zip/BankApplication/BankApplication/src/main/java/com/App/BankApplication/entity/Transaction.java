package com.App.BankApplication.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Transaction {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int transactionId;
	
	@Column(name="fromAcc" , updatable=false, nullable=false)
	private long fromAccount;
	
	@Column(name="toAcc" , updatable=false, nullable=false)
	private long toAccount;
	
	private int amount;
	
	private String comment;
	
	private LocalDate transationdate;

	public Transaction() {
		
	}
	
	public Transaction( long fromAccount, long toAccount, int amount, String comment,
			LocalDate transationdate) {
		super();
		this.fromAccount = fromAccount;
		this.toAccount = toAccount;
		this.amount = amount;
		this.comment = comment;
		this.transationdate = transationdate;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public long getFromAccount() {
		return fromAccount;
	}

	public void setFromAccount(long fromAccount) {
		this.fromAccount = fromAccount;
	}

	public long getToAccount() {
		return toAccount;
	}

	public void setToAccount(long toAccount) {
		this.toAccount = toAccount;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public LocalDate getTransationdate() {
		return transationdate;
	}

	public void setTransationdate(LocalDate transationdate) {
		this.transationdate = transationdate;
	}
	
	
}
