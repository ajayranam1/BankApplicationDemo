package com.App.BankApplication.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.App.BankApplication.entity.Customer;
import com.App.BankApplication.repository.CustomerRepository;

@Service
public class CustomerServiceIMPL implements CustomerService{

	@Autowired
	CustomerRepository customerRepo;
	
	@Override
	public Customer saveCustomer(Customer customer) {
		return customerRepo.save(customer);
	}
}
