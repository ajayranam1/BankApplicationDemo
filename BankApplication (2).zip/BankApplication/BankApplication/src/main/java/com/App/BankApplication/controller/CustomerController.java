package com.App.BankApplication.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.App.BankApplication.entity.Customer;
import com.App.BankApplication.service.CustomerService;


@RestController
public class CustomerController {

	@Autowired
	CustomerService custServ;
	
	@Autowired
	AccountController accCont;
	
	@PostMapping("/customer")
	public String createCustomer(@RequestBody Customer customer) {
		custServ.saveCustomer(customer);
		long acctNumber=accCont.createAccount(customer.getAccountId(), 1000);
		String message="User is succesfully registered with Account Number : "+acctNumber;
		return message;
	}
}
