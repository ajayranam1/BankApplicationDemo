package com.App.BankApplication.service;

import java.time.LocalDate;
import java.util.List;

import com.App.BankApplication.entity.Account;
import com.App.BankApplication.entity.Statement;

public interface AccountService {

	public Account saveAccount(Account acc);
	
	public long getAccountDetails(int accid);
	
	public String transferAmount(long fromAccount, long toAccount, int amount, String Comment);
	
	public String statementEntry(long fromAccount,long toAccount,int amount, LocalDate date,String comment);
	
	public List<Statement> viewStatement(long AccNumber);
}
