package com.App.BankApplication.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.App.BankApplication.entity.Account;
import com.App.BankApplication.entity.Statement;
import com.App.BankApplication.entity.Transaction;
import com.App.BankApplication.repository.AccountRepository;
import com.App.BankApplication.repository.StatementRepository;
import com.App.BankApplication.repository.TransactionRepository;

@Service
public class AccountServiceIMPL implements AccountService{
	
	@Autowired
	AccountRepository accountRepo;
	
	@Autowired
	TransactionRepository transRepo;
	
	@Autowired
	StatementRepository stateRepo;
	
	@Override
	public Account saveAccount(Account acc) {
		return accountRepo.save(acc);
	}
	@Override
	public long getAccountDetails(int accId) {
		return accountRepo.getAccNumberByAccountId(accId);
	}
	
	@Override
	public String transferAmount(long fromAccount, long toAccount, int amount,String comment) {
		String response = "Failed";
		Account accDetails=accountRepo.getOpenBalByAccNumber(fromAccount);
		if(accDetails.getOpenBal()<0 || accDetails.getOpenBal() < amount) {
			response = "Failed | Due to insuffiecent Balance";
		}
		else {
			accountRepo.withdrawAmountByAccNumber(amount, fromAccount);
			accountRepo.saveBalanceByAccNumber(amount, toAccount);
			LocalDate date=LocalDate.now();
			Transaction trans=new Transaction(fromAccount,toAccount,amount,comment,date);
			transRepo.save(trans);
			this.statementEntry(fromAccount,toAccount,amount,date,comment);
			response="Transaction successful with transactionId : "+trans.getTransactionId();
		}
		return response;
	}
	
	@Override
	public String statementEntry(long fromAccount, long toAccount, int amount,LocalDate date,String comment) {
		String response="Failed";
		Statement debitStmnt= new Statement(fromAccount,comment, amount,0,date);
		Statement creditStmnt= new Statement(toAccount,comment,0,amount,date);
		stateRepo.save(debitStmnt);
		stateRepo.save(creditStmnt);
		return response;
	}
	
	@Override
	public List<Statement> viewStatement(long accNumber) {
		return stateRepo.getAllByAccountNumber(accNumber);
	}
}

