package com.App.BankApplication.dto;

import java.time.LocalDate;

public class AccountDto {

	public AccountDto(int accNumber, LocalDate date, int openBal) {
		super();
		this.accNumber = accNumber;
		this.date = date;
		this.openBal = openBal;
	}
	
	private int accNumber;
	private LocalDate date;
	private int openBal;
	
	public int getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(int accNumber) {
		this.accNumber = accNumber;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public int getOpenBal() {
		return openBal;
	}
	public void setOpenBal(int openBal) {
		this.openBal = openBal;
	}
	
	
}
