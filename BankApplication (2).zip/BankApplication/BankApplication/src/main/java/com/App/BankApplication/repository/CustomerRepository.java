package com.App.BankApplication.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.App.BankApplication.entity.Customer;

@Repository
public interface CustomerRepository extends  CrudRepository<Customer, Integer>{

}
