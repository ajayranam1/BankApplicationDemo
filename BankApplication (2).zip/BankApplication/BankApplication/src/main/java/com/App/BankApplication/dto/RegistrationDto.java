package com.App.BankApplication.dto;

public class RegistrationDto {

	public RegistrationDto(String fname, String lname, int age, int uID, String phone, String email) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.age = age;
		UID = uID;
		this.phone = phone;
		this.email = email;
	}
	
	private String fname;
	private String lname;
	private int age;
	private int UID;
	private String phone;
	private String email;
	
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getUID() {
		return UID;
	}
	public void setUID(int uID) {
		UID = uID;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
}
