package com.App.BankApplication.entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Statement {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int statementId;
	
	private long accountNumber;
	private String comments;
	private int amountdDbt;
	private int amountCrd;
	private LocalDate date;
	
	public Statement() {
		
	}
	
	public Statement(long accountNumber, String comments, int amountdDbt, int amountCrd, LocalDate date) {
		super();
		this.accountNumber = accountNumber;
		this.comments = comments;
		this.amountdDbt = amountdDbt;
		this.amountCrd = amountCrd;
		this.date = date;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public int getAmountdDbt() {
		return amountdDbt;
	}

	public void setAmountdDbt(int amountdDbt) {
		this.amountdDbt = amountdDbt;
	}

	public int getAmountCrd() {
		return amountCrd;
	}

	public void setAmountCrd(int amountCrd) {
		this.amountCrd = amountCrd;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}
	
	
	
}
