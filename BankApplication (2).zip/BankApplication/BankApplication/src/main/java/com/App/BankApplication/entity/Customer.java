package com.App.BankApplication.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer {

	@Id
	@Column(name="accountId" , updatable=false, nullable=false)
	private int accountId;
	
	private String fName;

	private String lName;

	private int age;
	
	private String UID;
	
	private String phone;
	
	private String email;

	public Customer() {
		
	}
	
	public Customer(int accountId, String fName, String lName, int age, String uID, String phone, String email) {
		super();
		this.accountId = accountId;
		this.fName = fName;
		this.lName = lName;
		this.age = age;
		UID = uID;
		this.phone = phone;
		this.email = email;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getUID() {
		return UID;
	}

	public void setUID(String uID) {
		UID = uID;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
	
}
