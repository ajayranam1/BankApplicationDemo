package com.App.BankApplication.dto;

import java.time.LocalDate;

public class TransactionDto {
	
	public TransactionDto(int fromAcc, int toACc, int amount, String comment, LocalDate transactionDate) {
		super();
		this.fromAcc = fromAcc;
		this.toACc = toACc;
		this.amount = amount;
		this.comment = comment;
		this.transactionDate = transactionDate;
	}
	private int fromAcc;
	private int toACc;
	private int amount;
	private String comment;
	private LocalDate transactionDate;
	
	public int getFromAcc() {
		return fromAcc;
	}
	public void setFromAcc(int fromAcc) {
		this.fromAcc = fromAcc;
	}
	public int getToACc() {
		return toACc;
	}
	public void setToACc(int toACc) {
		this.toACc = toACc;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public LocalDate getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}
	
	
}
